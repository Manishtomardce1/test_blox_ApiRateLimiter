package service;

import java.util.HashMap;
import java.util.Map;

import constants.RateLimiterConstant;
import tokeBucketRateLimiter.TokenBucket;

public class RateLimiterService {
	Map<Integer, TokenBucket> bucket;
	
	public RateLimiterService(int id) {
		bucket = new HashMap<>();
		bucket.put(id,  new TokenBucket(RateLimiterConstant.BUCKET_SIZE, RateLimiterConstant.TIME_WINDOW));
	}
	
	public boolean accessApplication(int id) {
		if(bucket.get(id).grantAccess()) {
			System.out.println("Successful api call for customer "+id);
			return true;
		}
		System.out.println("HTTP 429 : Api call failed & penalised for additional one minute by rate limiter for customer "+id);
		bucket.get(id).penaliseUser();
		return false;
	}
}
