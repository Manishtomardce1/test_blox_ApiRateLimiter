package constants;

public class RateLimiterConstant {
	public static final int BUCKET_SIZE = 10;
	public static final int TIME_WINDOW = 60;
	public static final int PENALTY_TIME = 60;
}
