package tokeBucketRateLimiter;

public interface RateLimiter {
	
	public boolean grantAccess();

}
