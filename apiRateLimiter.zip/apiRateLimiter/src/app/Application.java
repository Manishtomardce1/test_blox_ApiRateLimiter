package app;

import service.RateLimiterService;

public class Application {

	public static void main(String[] args) throws InterruptedException {
		RateLimiterService userBucket1 = new RateLimiterService(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		
		RateLimiterService userBucket2 = new RateLimiterService(2);
		userBucket2.accessApplication(2);
		userBucket2.accessApplication(2);
		userBucket2.accessApplication(2);
		userBucket2.accessApplication(2);
		userBucket2.accessApplication(2);
		userBucket2.accessApplication(2);
		userBucket2.accessApplication(2);
			
		Thread t = Thread.currentThread();
		t.sleep(180000);

		userBucket1.accessApplication(1);
		
		
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		userBucket1.accessApplication(1);
		
	}

}
